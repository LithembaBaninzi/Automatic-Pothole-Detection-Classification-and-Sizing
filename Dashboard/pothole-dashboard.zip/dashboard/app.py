"""
Pothole Dashboard — Flask backend
==================================
Serves a dashboard that reads pothole detection CSV files and aggregates
them per track for visualisation.

Crops folder convention
-----------------------
For a CSV named  pothole_detections_<TS>.csv  the dashboard will look for
crops at:

    <project>/crops/pothole_crops_<TS>/pothole_track<N>.jpg

The CSV's image_file column already stores the full Pi-side path, e.g.
    /home/pi/pothole_crops_20260508_193308/pothole_track1.jpg
We extract just the last two components (subfolder + filename) and serve
them as /crops/pothole_crops_20260508_193308/pothole_track1.jpg

Deploy on PythonAnywhere — see README.md
"""
import os
import csv
import time
from collections import defaultdict
from flask import (Flask, render_template, jsonify, request,
                   send_from_directory, abort)
from werkzeug.utils import secure_filename
import zipfile
import tempfile
import shutil

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATA_DIR    = os.path.join(BASE_DIR, "data")
UPLOAD_DIR  = os.path.join(BASE_DIR, "uploads")
CROPS_DIR   = os.path.join(BASE_DIR, "crops")
ALLOWED_EXT = {"csv"}

os.makedirs(DATA_DIR,   exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(CROPS_DIR,  exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024   # 50 MB upload cap


# ── Helpers ──────────────────────────────────────────────────────────────────

def boxes_overlap(box_a, box_b, gap_px=3):
    """Return True if two pixel boxes (x1,y1,x2,y2) touch or overlap."""
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b
    ax1 -= gap_px; ay1 -= gap_px
    ax2 += gap_px; ay2 += gap_px
    return not (ax2 < bx1 or bx2 < ax1 or ay2 < by1 or by2 < ay1)

def merge_tracks_by_overlap(tracks):
    """Cluster tracks by repair box pixel overlap."""
    n = len(tracks)
    if n == 0:
        return []
    parent = list(range(n))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(x, y):
        rx, ry = find(x), find(y)
        if rx != ry:
            parent[ry] = rx

    # Build boxes from each track (use first occurrence values, consistent across frames)
    boxes = []
    for t in tracks:
        try:
            x1 = int(t.get('repair_box_x1', 0))
            y1 = int(t.get('repair_box_y1', 0))
            x2 = int(t.get('repair_box_x2', 0))
            y2 = int(t.get('repair_box_y2', 0))
            boxes.append((x1, y1, x2, y2))
        except:
            boxes.append(None)

    for i in range(n):
        if boxes[i] is None: continue
        for j in range(i+1, n):
            if boxes[j] is None: continue
            if boxes_overlap(boxes[i], boxes[j]):
                union(i, j)

    from collections import defaultdict
    clusters = defaultdict(list)
    for i in range(n):
        clusters[find(i)].append(i)
    return list(clusters.values())

def merge_repair_boxes_in_cluster(tracks):
    """Merge a cluster of tracks into one group.
       Returns a dict with:
       - track_ids: list of original track IDs
       - n_potholes: number of tracks
       - total_area_m2: sum of physical areas
       - avg_confidence: average confidence
       - repair_label: label of the largest track (or most frequent)
       - repair_w_m, repair_h_m, repair_area_m2: UNION of pixel boxes (scaled to meters)
       - lat, lon: centroid of available GPS coordinates
    """
    if not tracks:
        return None

    # Collect track IDs
    track_ids = [t['id'] for t in tracks]

    # Compute union of pixel repair boxes (x1,y1,x2,y2)
    min_x1 = min(t.get('repair_box_x1', 0) for t in tracks)
    min_y1 = min(t.get('repair_box_y1', 0) for t in tracks)
    max_x2 = max(t.get('repair_box_x2', 0) for t in tracks)
    max_y2 = max(t.get('repair_box_y2', 0) for t in tracks)

    # Union width/height in pixels
    union_w_px = max_x2 - min_x1
    union_h_px = max_y2 - min_y1

    # To convert pixels to meters, we need an average scale factor.
    # Use each track's known physical width vs its pixel width (if available).
    scales_w = []
    scales_h = []
    for t in tracks:
        px_w = t.get('repair_box_x2', 0) - t.get('repair_box_x1', 0)
        px_h = t.get('repair_box_y2', 0) - t.get('repair_box_y1', 0)
        phys_w = t.get('repair_w_m', 0)
        phys_h = t.get('repair_h_m', 0)
        if px_w > 0 and phys_w > 0:
            scales_w.append(phys_w / px_w)
        if px_h > 0 and phys_h > 0:
            scales_h.append(phys_h / px_h)

    avg_scale_w = sum(scales_w) / len(scales_w) if scales_w else 0.005   # fallback ~5 mm/px
    avg_scale_h = sum(scales_h) / len(scales_h) if scales_h else 0.005

    merged_w_m = union_w_px * avg_scale_w
    merged_h_m = union_h_px * avg_scale_h
    merged_area_m2 = merged_w_m * merged_h_m

    # Total physical area (sum) – keep for reference
    total_phys_area = sum(t.get('repair_area_m2', 0) for t in tracks)

    # Average confidence
    avg_conf = sum(t.get('confidence', 0) for t in tracks) / len(tracks)

    # Repair label: choose the one from the largest area (or most common)
    largest = max(tracks, key=lambda t: t.get('repair_area_m2', 0))
    repair_label = largest.get('repair_label', '?')

    # GPS location: average of all non‑None lat/lon pairs
    lats = [t['lat'] for t in tracks if t.get('lat') is not None]
    lons = [t['lon'] for t in tracks if t.get('lon') is not None]
    if lats and lons:
        lat = round(sum(lats) / len(lats), 6)
        lon = round(sum(lons) / len(lons), 6)
    else:
        lat = lon = None

    return {
        'track_ids': track_ids,
        'n_potholes': len(tracks),
        'total_area_m2': round(total_phys_area, 2),
        'avg_confidence': round(avg_conf, 2),
        'repair_label': repair_label,
        'repair_w_m': round(merged_w_m, 3),
        'repair_h_m': round(merged_h_m, 3),
        'repair_area_m2': round(merged_area_m2, 3),
        'lat': lat,
        'lon': lon,
    }

def _allowed(name):
    return "." in name and name.rsplit(".", 1)[1].lower() in ALLOWED_EXT


def _safe_float(v, default=0.0):
    try:
        return float(v) if v not in (None, "") else default
    except (ValueError, TypeError):
        return default


def _csv_timestamp(csv_filename):
    """
    Extract the timestamp portion from a CSV filename.
        pothole_detections_20260508_193308.csv → 20260508_193308
    """
    base = os.path.splitext(os.path.basename(csv_filename))[0]
    parts = base.split("_")
    # Take the last two underscore-separated tokens (date + time)
    if len(parts) >= 2:
        return "_".join(parts[-2:])
    return ""


def _crop_relpath(image_file_value, csv_filename):
    """
    Build  pothole_crops_<TS>/<filename>  from the CSV's image_file column.

    Falls back to deriving the subfolder from the CSV name itself if the
    image_file path doesn't contain it (e.g. a CSV produced on a different
    machine).
    """
    if not image_file_value:
        return ""
    name = os.path.basename(image_file_value)
    # Try to grab the subfolder from the original Pi path
    parent = os.path.basename(os.path.dirname(image_file_value))
    if parent.startswith("pothole_crops_"):
        return f"{parent}/{name}"
    # Fall back: derive from CSV filename
    ts = _csv_timestamp(csv_filename)
    if ts:
        return f"pothole_crops_{ts}/{name}"
    return name


def aggregate_csv(path):
    """Read CSV and aggregate per-detection rows into one row per track_id.
       Now includes repair box pixel coordinates for merging."""
    if not os.path.isfile(path):
        return []

    csv_name = os.path.basename(path)
    rows = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    if not rows:
        return []

    by_track = defaultdict(list)
    for r in rows:
        by_track[r.get("track_id", "0")].append(r)

    out = []
    for tid, trows in sorted(by_track.items(), key=lambda x: int(x[0])):
        def avg(field):
            vals = [_safe_float(r.get(field)) for r in trows]
            return sum(vals) / len(vals) if vals else 0.0

        r0 = trows[0]   # first detection of this track (used for box coordinates)

        lat = next((float(r["gps_lat"]) for r in trows if r.get("gps_lat")), None)
        lon = next((float(r["gps_lon"]) for r in trows if r.get("gps_lon")), None)

        image_file = r0.get("image_file", "")
        image_rel  = _crop_relpath(image_file, csv_name)

        out.append({
            "id":             int(tid),
            "timestamp":      r0.get("timestamp", ""),
            "frames":         len(trows),
            "width_cm":       round(avg("width_cm"), 1),
            "height_cm":      round(avg("height_cm"), 1),
            "box_area_cm2":   round(avg("box_area_cm2"), 0),
            "pixel_area_cm2": round(avg("pixel_area_cm2"), 0),
            "box_area_m2":    round(avg("box_area_m2"), 4),
            "repair_w_m":     _safe_float(r0.get("repair_box_w_m"), 0.5),
            "repair_h_m":     _safe_float(r0.get("repair_box_h_m"), 0.5),
            "repair_area_m2": _safe_float(r0.get("repair_box_area_m2"), 0.25),
            "repair_label":   r0.get("repair_label", ""),
            "confidence":     round(avg("confidence"), 2),
            "method":         r0.get("method", ""),
            "lat":            lat,
            "lon":            lon,
            "weather":        r0.get("weather", ""),
            "device_id":      r0.get("device_id", ""),
            "source":         r0.get("source", ""),
            "image_file":     os.path.basename(image_file),
            "image_rel":      image_rel,
            # ----- ADD THESE FOUR LINES -----
            "repair_box_x1":  _safe_float(r0.get("repair_box_x1")),
            "repair_box_y1":  _safe_float(r0.get("repair_box_y1")),
            "repair_box_x2":  _safe_float(r0.get("repair_box_x2")),
            "repair_box_y2":  _safe_float(r0.get("repair_box_y2")),
        })
    return out


def list_sessions():
    """Find all CSVs in data/ and uploads/, newest first."""
    files = []
    for folder in (DATA_DIR, UPLOAD_DIR):
        for name in os.listdir(folder):
            if name.lower().endswith(".csv"):
                p = os.path.join(folder, name)
                files.append({
                    "name":    name,
                    "path":    p,
                    "size_kb": round(os.path.getsize(p) / 1024, 1),
                    "mtime":   os.path.getmtime(p),
                })
    return sorted(files, key=lambda x: x["mtime"], reverse=True)


def find_csv_path(name):
    safe = secure_filename(name)
    for folder in (DATA_DIR, UPLOAD_DIR):
        path = os.path.join(folder, safe)
        if os.path.isfile(path):
            return path
    return None


# ── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/sessions")
def api_sessions():
    sessions = list_sessions()
    return jsonify([{
        "name":    s["name"],
        "size_kb": s["size_kb"],
        "mtime":   s["mtime"],
        "label":   time.strftime("%Y-%m-%d %H:%M",
                                 time.localtime(s["mtime"])),
    } for s in sessions])


@app.route("/api/data")
def api_data():
    name = request.args.get("file")
    if name:
        path = find_csv_path(name)
        if not path:
            return jsonify({"error": "File not found"}), 404
    else:
        sessions = list_sessions()
        if not sessions:
            return jsonify([])
        path = sessions[0]["path"]
    return jsonify(aggregate_csv(path))


@app.route("/api/upload", methods=["POST"])
def api_upload():
    if "file" not in request.files:
        return jsonify({"error": "No file in request"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "No file selected"}), 400
    if not _allowed(f.filename):
        return jsonify({"error": "Only .csv files are accepted"}), 400

    name = secure_filename(f.filename)
    path = os.path.join(UPLOAD_DIR, name)
    f.save(path)
    return jsonify({"success": True, "filename": name})

@app.route("/api/merged")
def api_merged():
    name = request.args.get("file")
    if name:
        path = find_csv_path(name)
        if not path:
            return jsonify({"error": "File not found"}), 404
    else:
        sessions = list_sessions()
        if not sessions:
            return jsonify([])
        path = sessions[0]["path"]

    tracks = aggregate_csv(path)
    if not tracks:
        return jsonify([])

    clusters = merge_tracks_by_overlap(tracks)
    result = []
    for idx, cluster_indices in enumerate(clusters):
        cluster_tracks = [tracks[i] for i in cluster_indices]
        merged = merge_repair_boxes_in_cluster(cluster_tracks)
        result.append({
            "group_id": idx + 1,
            "track_ids": merged['track_ids'],          # list of original IDs
            "n_potholes": merged['n_potholes'],
            "total_area_m2": merged['total_area_m2'],
            "avg_confidence": merged['avg_confidence'],
            "repair_label": merged['repair_label'],
            "repair_w_m": merged['repair_w_m'],
            "repair_h_m": merged['repair_h_m'],
            "repair_area_m2": merged['repair_area_m2'],
            "lat": merged['lat'],
            "lon": merged['lon'],
        })
    return jsonify(result)

@app.route("/crops/<path:filename>")
def serve_crop(filename):
    """
    Serve crop images from <project>/crops/<filename>.
    The <path:…> converter allows nested subfolders, so URLs like
        /crops/pothole_crops_20260508_193308/pothole_track1.jpg
    resolve correctly.
    """
    full = os.path.normpath(os.path.join(CROPS_DIR, filename))
    if not full.startswith(CROPS_DIR):
        abort(403)
    if not os.path.isfile(full):
        abort(404)
    rel_dir, fname = os.path.split(filename)
    return send_from_directory(os.path.join(CROPS_DIR, rel_dir), fname)

@app.route("/api/upload_bundle", methods=["POST"])
def api_upload_bundle():
    # Get the two files
    csv_file = request.files.get("csv")
    zip_file = request.files.get("zip")
    if not csv_file or not csv_file.filename:
        return jsonify({"error": "CSV file is required"}), 400
    if not csv_file.filename.endswith(".csv"):
        return jsonify({"error": "Only .csv files are accepted"}), 400
    if zip_file and not zip_file.filename.endswith(".zip"):
        return jsonify({"error": "Only .zip files are accepted for images"}), 400

    # Save CSV
    csv_name = secure_filename(csv_file.filename)
    csv_path = os.path.join(DATA_DIR, csv_name)  # or UPLOAD_DIR, but we want it in data
    csv_file.save(csv_path)

    # Extract timestamp from CSV filename (pothole_detections_YYYYMMDD_HHMMSS.csv)
    base = os.path.splitext(csv_name)[0]
    parts = base.split("_")
    if len(parts) >= 4 and parts[0] == "pothole" and parts[1] == "detections":
        ts = "_".join(parts[2:4])  # e.g., 20260508_193308
    else:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Process ZIP if provided
    if zip_file:
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                zip_path = os.path.join(tmpdir, "crops.zip")
                zip_file.save(zip_path)
                with zipfile.ZipFile(zip_path, 'r') as zf:
                    # The ZIP should contain a folder (or directly the images). We'll extract to crops/pothole_crops_<TS>/
                    target_dir = os.path.join(CROPS_DIR, f"pothole_crops_{ts}")
                    os.makedirs(target_dir, exist_ok=True)
                    # Extract all contents; if the zip has a top-level folder, we'll move its contents up
                    zf.extractall(target_dir)
                    # If there's a single subfolder, move contents up (optional)
                    items = os.listdir(target_dir)
                    if len(items) == 1 and os.path.isdir(os.path.join(target_dir, items[0])):
                        subfolder = os.path.join(target_dir, items[0])
                        for f in os.listdir(subfolder):
                            shutil.move(os.path.join(subfolder, f), target_dir)
                        os.rmdir(subfolder)
        except Exception as e:
            # If ZIP extraction fails, still keep the CSV
            print(f"ZIP extraction error: {e}")
            return jsonify({"error": f"ZIP extraction failed: {e}"}), 500

    # After successful upload, the dashboard will pick up the CSV via /api/sessions
    # and images via /crops/...
    return jsonify({"success": True, "csv_filename": csv_name, "timestamp": ts})

@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "File too large (max 50 MB)"}), 413


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
