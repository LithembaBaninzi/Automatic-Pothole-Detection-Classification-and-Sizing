"""
PythonAnywhere WSGI configuration.
==================================
Copy these contents into your /var/www/<username>_pythonanywhere_com_wsgi.py
file (accessible from the Web tab → WSGI configuration link).

Replace <YOUR_USERNAME> with your actual PythonAnywhere username.
"""

import sys

# Adjust this path to match your folder location on PythonAnywhere
project_path = "/home/<YOUR_USERNAME>/mysite"
if project_path not in sys.path:
    sys.path.insert(0, project_path)

from app import app as application
