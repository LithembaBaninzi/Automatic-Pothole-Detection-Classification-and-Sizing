# Pothole Inspector — Web Dashboard

Flask-based dashboard that reads pothole detection CSV files and displays
aggregated statistics, a map of GPS-located potholes, a size distribution
chart, and a sortable/filterable data table.

## Folder structure

```
dashboard/
├── app.py                  ← Flask backend
├── wsgi.py                 ← For PythonAnywhere
├── requirements.txt
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/main.js
├── data/                   ← Place CSV files here
│   └── pothole_detections_20260508_193308.csv
├── uploads/                ← User-uploaded CSVs go here
└── crops/                  ← Pothole crop folders (one per session)
    └── pothole_crops_20260508_193308/
        ├── pothole_track1.jpg
        ├── pothole_track2.jpg
        └── …
```

**Naming convention:** for a CSV `pothole_detections_<TIMESTAMP>.csv`,
the matching crops live in `crops/pothole_crops_<TIMESTAMP>/`. The
backend reads the parent folder name from the CSV's `image_file` column
and serves crops from there.

## Run locally

```bash
pip install flask
cd dashboard
python app.py
# → http://localhost:5000
```

The included `data/pothole_detections_20260508_193308.csv` will load
automatically. Drop more CSVs in `data/` (or use the **Upload** button)
to add more sessions.

## Deploy to PythonAnywhere

1. **Upload** the `dashboard/` folder. Easiest:
   ```bash
   # On your laptop
   cd dashboard && zip -r ../dashboard.zip .
   ```
   Upload `dashboard.zip` via the Files tab, then in a Bash console:
   ```bash
   cd ~
   unzip dashboard.zip -d mysite
   ```

2. **Install Flask:**
   ```bash
   pip install --user flask
   ```

3. **Web tab → Add a new web app:**
   - Manual configuration
   - Python 3.10 or higher

4. **Edit the WSGI config** (linked from the Web tab) — replace contents
   with `wsgi.py`, adjusting `<YOUR_USERNAME>`.

5. **Source code & working directory** → `/home/<username>/mysite/`.

6. **Reload** the web app.

## Adding crops from the Pi

After a Pi run, copy the crops folder to PythonAnywhere preserving the
folder name:

```bash
# On the Pi, scp to PythonAnywhere (paid plan only, otherwise upload via the Files tab)
scp -r ~/pothole_crops_20260508_193308/ \
       <user>@ssh.pythonanywhere.com:/home/<user>/mysite/crops/
```

Or compress, upload via the Files tab, and unzip:
```bash
cd ~/pothole_crops_20260508_193308
zip -r ~/crops_20260508_193308.zip .
# Upload, then:
unzip ~/crops_20260508_193308.zip -d ~/mysite/crops/pothole_crops_20260508_193308/
```

## Theme

Dark theme is the default. Click the sun/moon icon in the topbar to
switch — the choice persists in localStorage. Both themes use the same
severity colour mapping (green / amber / red).

## API

- `GET /` — dashboard
- `GET /api/sessions` — list of CSV files with timestamps
- `GET /api/data?file=<name>` — aggregated data (defaults to newest CSV)
- `POST /api/upload` — multipart CSV upload
- `GET /crops/<subfolder>/<filename>` — pothole crop image
