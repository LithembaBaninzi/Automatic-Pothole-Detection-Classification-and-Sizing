/* ============================================================================
   Pothole Inspector — front-end logic (v2)
   - Theme toggle (dark/light) with localStorage persistence
   - Theme-aware Leaflet tiles
   - Crops fetched as /crops/<image_rel> (timestamped subfolders)
   ============================================================================ */

(() => {

  // ── State ─────────────────────────────────────────────────────────────
  let allData    = [];
  let sortKey    = "id";
  let sortAsc    = true;
  let map        = null;
  let mapMarkers = [];
  let mapTileLayer = null;
  let chart      = null;
  let currentSession = null;
  let allGroups = [];
  let groupSortKey = "group_id";
  let groupSortAsc = true;

  // ── DOM helpers ───────────────────────────────────────────────────────
  const $  = sel => document.querySelector(sel);
  const $$ = sel => document.querySelectorAll(sel);

  // ── Inline SVG icons ──────────────────────────────────────────────────
  const ICON_IMAGE = `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="12" height="10" rx="1"/><circle cx="6" cy="7" r="1"/><path d="M14 10l-3-3-5 5"/></svg>`;
  const ICON_PIN   = `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M8 14s5-4 5-8a5 5 0 0 0-10 0c0 4 5 8 5 8z"/><circle cx="8" cy="6" r="1.5"/></svg>`;

  // ── Severity helpers ──────────────────────────────────────────────────
  function severity(area) {
    if (area < 150) return "sm";
    if (area <= 400) return "md";
    return "lg";
  }
  function severityLabel(area) {
    const s = severity(area);
    if (s === "sm") return '<span class="badge badge-sm">Small</span>';
    if (s === "md") return '<span class="badge badge-md">Medium</span>';
    return            '<span class="badge badge-lg">Large</span>';
  }

  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  // ── Toast ─────────────────────────────────────────────────────────────
  function toast(msg, isError) {
    let el = document.querySelector(".toast");
    if (!el) {
      el = document.createElement("div");
      el.className = "toast";
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.toggle("error", !!isError);
    el.classList.add("show");
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove("show"), 3500);
  }

  // ── Theme toggle ──────────────────────────────────────────────────────
  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem("theme", theme); } catch (e) {}
    if (chart) updateChartColors();
  }

  function initTheme() {
    let theme;
    try { theme = localStorage.getItem("theme"); } catch (e) {}
    if (!theme) {
      theme = window.matchMedia("(prefers-color-scheme: light)").matches
        ? "light" : "dark";
    }
    setTheme(theme);
  }

  // ── API ───────────────────────────────────────────────────────────────
  async function fetchSessions() {
    try {
      const r = await fetch("/api/sessions");
      return await r.json();
    } catch (e) {
      console.error(e); return [];
    }
  }

  async function fetchData(filename) {
    try {
      const url = filename ? `/api/data?file=${encodeURIComponent(filename)}`
                           : "/api/data";
      const r = await fetch(url);
      if (!r.ok) {
        const j = await r.json().catch(() => ({}));
        throw new Error(j.error || `HTTP ${r.status}`);
      }
      return await r.json();
    } catch (e) {
      console.error(e); toast(`Load failed: ${e.message}`, true);
      return [];
    }
  }

  // ── Map setup (fixed tiles, no theme switch) ───────────────────────────
  function initMap() {
    map = L.map("map", {
      zoomControl: true,
      minZoom: 3,
      maxZoom: 19,
    });
    // Add scale bar (metric only)
    L.control.scale({ metric: true, imperial: false }).addTo(map);
    // Use standard OpenStreetMap tiles (detailed, colourful)
    const osmTileLayer = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);
    // Store the layer so we never replace it (no theme switching)
    mapTileLayer = osmTileLayer;
    // Initial view (will be overridden when data loads)
    map.setView([-33.9587, 18.4597], 13);
  }
  

  function updateMap(data) {
    mapMarkers.forEach(m => map.removeLayer(m));
    mapMarkers = [];

    const located = data.filter(d => d.lat && d.lon);
    $("#map-count").textContent = `${located.length} located`;
    if (!located.length) return;

    located.forEach(d => {
      const sev = severity(d.box_area_cm2);
      const col = sev === "sm" ? cssVar("--sev-sm")
                : sev === "md" ? cssVar("--sev-md")
                : cssVar("--sev-lg");
      const surface = cssVar("--surface");
      const icon = L.divIcon({
        className: "",
        html: `<div style="width:26px;height:26px;background:${col};border:2px solid ${surface};border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,0.35);display:flex;align-items:center;justify-content:center;font-family:'IBM Plex Mono',monospace;font-size:11px;font-weight:600;color:#fff;">${d.id}</div>`,
        iconSize: [26, 26],
        iconAnchor: [13, 13],
        popupAnchor: [0, -14],
      });
      const m = L.marker([d.lat, d.lon], { icon }).addTo(map).bindPopup(`
        <div class="popup-title">Pothole #${d.id}</div>
        <div class="popup-row"><span>Size</span><b>${d.width_cm}×${d.height_cm} cm</b></div>
        <div class="popup-row"><span>Box Area</span><b>${d.box_area_cm2} cm²</b></div>
        <div class="popup-row"><span>Repair</span><b>${d.repair_label}</b></div>
        <div class="popup-row"><span>Confidence</span><b>${(d.confidence*100).toFixed(0)}%</b></div>
        <div style="margin-top:6px;font-size:0.66rem;color:var(--muted-2)">${d.lat.toFixed(6)}, ${d.lon.toFixed(6)}</div>
      `);
      mapMarkers.push(m);
    });

    if (located.length > 1) {
      const bounds = L.latLngBounds(located.map(d => [d.lat, d.lon]));
      map.fitBounds(bounds, { padding: [60, 60], maxZoom: 19 });
    } else {
      map.setView([located[0].lat, located[0].lon], 19);
    }
  }

  // ── Chart ─────────────────────────────────────────────────────────────
  function initChart() {
    const ctx = $("#chart").getContext("2d");
    chart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Small", "Medium", "Large"],
        datasets: [{
          data: [0, 0, 0],
          backgroundColor: [],
          borderRadius: 4,
          borderWidth: 0,
          maxBarThickness: 72,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 250 },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#0d1117",
            borderColor: "#30363d",
            borderWidth: 1,
            titleColor: "#e6edf3",
            bodyColor: "#c9d1d9",
            titleFont: { family: "IBM Plex Mono", size: 11 },
            bodyFont:  { family: "IBM Plex Mono", size: 11 },
            padding: 8,
            displayColors: false,
            callbacks: {
              label: c => ` ${c.raw} pothole${c.raw === 1 ? "" : "s"}`,
            },
          },
        },
        scales: {
          x: { grid: { display: false }, ticks: {} },
          y: { beginAtZero: true, grid: {}, ticks: { stepSize: 1 } },
        },
      },
    });
    updateChartColors();
  }

  function updateChartColors() {
    if (!chart) return;
    const isLight = document.documentElement.dataset.theme === "light";
    chart.data.datasets[0].backgroundColor = [
      cssVar("--sev-sm"), cssVar("--sev-md"), cssVar("--sev-lg")
    ];
    chart.options.scales.x.ticks = {
      color: cssVar("--text-soft"),
      font: { family: "IBM Plex Mono", size: 11, weight: "500" },
    };
    chart.options.scales.y.ticks = {
      color: cssVar("--muted"),
      stepSize: 1,
      font: { family: "IBM Plex Mono", size: 10 },
    };
    chart.options.scales.y.grid = {
      color: isLight ? "rgba(31,35,40,0.08)" : "rgba(48,54,61,0.5)"
    };
    chart.options.plugins.tooltip.backgroundColor = cssVar("--surface");
    chart.options.plugins.tooltip.borderColor = cssVar("--border");
    chart.options.plugins.tooltip.titleColor = cssVar("--text");
    chart.options.plugins.tooltip.bodyColor = cssVar("--text-soft");
    chart.update("none");
  }

  function updateChart(data) {
    const counts = { sm: 0, md: 0, lg: 0 };
    data.forEach(d => counts[severity(d.box_area_cm2)]++);
    chart.data.datasets[0].data = [counts.sm, counts.md, counts.lg];
    chart.update();
  }

  // ── Stats ─────────────────────────────────────────────────────────────
  function updateStats(data) {
    const n = data.length;
    $("#stat-total").textContent = n;
    if (!n) {
      ["#stat-avg-area", "#stat-avg-mask", "#stat-repair", "#stat-conf"]
        .forEach(s => $(s).textContent = "—");
      $("#meta-coverage").textContent = "0%";
      $("#meta-method").textContent = "—";
      return;
    }
    const totalDet = data.reduce((s, d) => s + d.frames, 0);
    const avgArea  = data.reduce((s, d) => s + d.box_area_cm2,   0) / n;
    const avgMask  = data.reduce((s, d) => s + d.pixel_area_cm2, 0) / n;
    const totalR   = data.reduce((s, d) => s + d.repair_area_m2, 0);
    const avgConf  = data.reduce((s, d) => s + d.confidence,     0) / n;
    const located  = data.filter(d => d.lat).length;
    const minArea  = Math.min(...data.map(d => d.box_area_cm2));
    const maxArea  = Math.max(...data.map(d => d.box_area_cm2));
    const minConf  = Math.min(...data.map(d => d.confidence));
    const maxConf  = Math.max(...data.map(d => d.confidence));

    $("#stat-avg-area").textContent      = avgArea.toFixed(0);
    $("#stat-avg-mask").textContent      = avgMask.toFixed(0);
    $("#stat-repair").textContent        = totalR.toFixed(2);
    $("#stat-conf").textContent          = (avgConf * 100).toFixed(0);
    $("#stat-total-detail").textContent  = `${totalDet.toLocaleString()} total detections`;
    $("#stat-area-range").textContent    = `Range ${minArea}–${maxArea} cm²`;
    $("#stat-repair-detail").textContent = `${(totalR * 10000).toFixed(0)} cm² of asphalt`;
    $("#stat-conf-range").textContent    = `Range ${(minConf*100).toFixed(0)}–${(maxConf*100).toFixed(0)}%`;

    $("#meta-fps").textContent      = "~23 fps";
    $("#meta-coverage").textContent = `${Math.round(located / n * 100)}%`;
    $("#meta-method").textContent   = data[0].method || "IE";
  }

  // ── Filters ───────────────────────────────────────────────────────────
  function applyFilters() {
    const q     = $("#search").value.toLowerCase();
    const sFilt = $("#filter-size").value;
    const cFilt = parseFloat($("#filter-conf").value) || 0;
    const gFilt = $("#filter-gps").value;

    let rows = allData.filter(d => {
      const blob = `${d.id} ${d.timestamp} ${d.lat || ""} ${d.lon || ""}`.toLowerCase();
      if (q && !blob.includes(q)) return false;
      if (sFilt !== "all" && severity(d.box_area_cm2) !== sFilt) return false;
      if (d.confidence < cFilt) return false;
      if (gFilt === "yes" && !d.lat) return false;
      if (gFilt === "no"  &&  d.lat) return false;
      return true;
    });

    rows.sort((a, b) => {
      const av = a[sortKey], bv = b[sortKey];
      if (av == null) return 1;
      if (bv == null) return -1;
      const cmp = (typeof av === "string")
        ? av.localeCompare(bv)
        : (av < bv ? -1 : av > bv ? 1 : 0);
      return sortAsc ? cmp : -cmp;
    });

    renderTable(rows);
    $("#row-count").textContent = `${rows.length} of ${allData.length} potholes`;
  }

  function renderTable(data) {
    const tbody = $("#tbody");
    if (!data.length) {
      tbody.innerHTML = '<tr><td colspan="12" class="empty">No matching potholes</td></tr>';
      return;
    }
    tbody.innerHTML = data.map(d => {
      const sev = severity(d.box_area_cm2);
      const imgHtml = d.image_rel
        ? `<div class="thumb"><img src="/crops/${d.image_rel}" alt="" onerror="this.parentElement.innerHTML='${ICON_IMAGE.replace(/'/g, '&apos;')}'"></div>`
        : `<div class="thumb">${ICON_IMAGE}</div>`;
      const gpsHtml = d.lat
        ? `<span class="gps">${ICON_PIN}${d.lat.toFixed(4)}, ${d.lon.toFixed(4)}</span>`
        : `<span class="gps-none">—</span>`;
      return `<tr class="sev-${sev}" data-id="${d.id}">
        <td><span class="pid">${d.id}</span></td>
        <td>${imgHtml}</td>
        <td class="mono">${d.timestamp}</td>
        <td class="mono">${d.width_cm}</td>
        <td class="mono">${d.height_cm}</td>
        <td class="strong">${d.box_area_cm2}</td>
        <td class="mono">${d.pixel_area_cm2}</td>
        <td>
          <div class="repair-cell">
            <span class="repair-label">${d.repair_label}</span>
            <span class="repair-area">${d.repair_area_m2} m²</span>
          </div>
        </td>
        <td>
          <div class="conf-bar">
            <div class="conf-track"><div class="conf-fill" style="width:${d.confidence*100}%"></div></div>
            <span class="conf-num">${(d.confidence*100).toFixed(0)}%</span>
          </div>
        </td>
        <td>${severityLabel(d.box_area_cm2)}</td>
        <td>${gpsHtml}</td>
        <td class="dim">${d.frames}</td>
      </tr>`;
    }).join("");

    $$("#tbody tr").forEach(tr => {
      tr.addEventListener("click", () => {
        const id = parseInt(tr.dataset.id, 10);
        const d  = allData.find(x => x.id === id);
        if (d) showDetail(d);
      });
    });
  }
  async function fetchMerged(filename) {
    const url = filename ? `/api/merged?file=${encodeURIComponent(filename)}` : "/api/merged";
    const r = await fetch(url);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }

  function applyGroupFilters() {
    const search = ($("#group-search")?.value || "").toLowerCase();
    const minArea = parseFloat($("#group-min-area")?.value) || 0;
    const maxArea = parseFloat($("#group-max-area")?.value) || Infinity;
    const minWidth = parseFloat($("#group-min-width")?.value) || 0;
    const maxWidth = parseFloat($("#group-max-width")?.value) || Infinity;
    const minHeight = parseFloat($("#group-min-height")?.value) || 0;
    const maxHeight = parseFloat($("#group-max-height")?.value) || Infinity;
    const minCount = parseInt($("#group-min-count")?.value) || 1;

    let filtered = allGroups.filter(g => {
      if (search && !(`${g.group_id} ${g.lat} ${g.lon}`.toLowerCase().includes(search))) return false;
      if (g.total_area_m2 < minArea || g.total_area_m2 > maxArea) return false;
      if (g.repair_w_m < minWidth || g.repair_w_m > maxWidth) return false;
      if (g.repair_h_m < minHeight || g.repair_h_m > maxHeight) return false;
      if (g.n_potholes < minCount) return false;
      return true;
    });

    // Sort
    filtered.sort((a, b) => {
      let av = a[groupSortKey], bv = b[groupSortKey];
      if (av == null) av = "";
      if (bv == null) bv = "";
      if (typeof av === "string") av = av.toLowerCase();
      if (typeof bv === "string") bv = bv.toLowerCase();
      if (av < bv) return groupSortAsc ? -1 : 1;
      if (av > bv) return groupSortAsc ? 1 : -1;
      return 0;
    });

    renderGroups(filtered);
    $("#group-row-count").textContent = `${filtered.length} of ${allGroups.length} groups`;
  }

  function renderGroups(groups) {
    const tbody = $("#group-tbody");
    if (!groups.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="empty">No matching groups</td></tr>';
      return;
    }
    tbody.innerHTML = groups.map(g => `
      <tr data-group-id="${g.group_id}">
        <td class="strong">${g.group_id}</td>
        <td class="mono">${g.n_potholes}</td>
        <td class="mono">${g.total_area_m2.toFixed(2)}</td>
        <td><span class="repair-label">${g.repair_label}</span></td>
        <td class="mono">${g.repair_area_m2.toFixed(2)}</td>
        <td><div class="conf-bar"><div class="conf-track"><div class="conf-fill" style="width:${g.avg_confidence*100}%"></div></div><span class="conf-num">${(g.avg_confidence*100).toFixed(0)}%</span></div></td>
        <td><span class="gps">${g.lat.toFixed(5)}, ${g.lon.toFixed(5)}</span></td>
        <td><button class="btn-sm group-detail-btn" data-id="${g.group_id}">Details</button></td>
      </tr>
    `).join("");
    // attach event listeners to detail buttons
    document.querySelectorAll(".group-detail-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const id = parseInt(btn.dataset.id, 10);
        const group = allGroups.find(g => g.group_id === id);
        if (group) showGroupDetail(group);
      });
    });
  }

  function showGroupDetail(group) {
    // simple modal or alert – you can expand later
    alert(`Group #${group.group_id}\nPotholes: ${group.n_potholes}\nTotal Area: ${group.total_area_m2} m²\nRepair Box: ${group.repair_label}\nAverage Confidence: ${(group.avg_confidence*100).toFixed(0)}%`);
  }

  // In loadAndRender, also call fetchMerged and store
  async function loadAndRender(data, filename) {
    allData = data;
    updateStats(data);
    updateChart(data);
    updateMap(data);
    applyFilters();  // individual table filters

    // Load groups
    try {
      allGroups = await fetchMerged(filename);
      applyGroupFilters();
    } catch (e) {
      console.error(e);
      allGroups = [];
      renderGroups([]);
    }
  }

  function sortBy(key) {
    if (sortKey === key) sortAsc = !sortAsc;
    else { sortKey = key; sortAsc = true; }
    $$("th[data-sort]").forEach(th => th.classList.remove("sorted"));
    const target = document.querySelector(`th[data-sort="${key}"]`);
    if (target) {
      target.classList.add("sorted");
      target.setAttribute("data-arrow", sortAsc ? "↑" : "↓");
    }
    applyFilters();
  }

  // ── Detail modal ──────────────────────────────────────────────────────
  function showDetail(d) {
    $("#modal-title").innerHTML = `Pothole #${d.id} <span style="color:var(--muted);font-weight:400"> · ${d.timestamp}</span>`;
    const imgEl = $("#modal-img");
    if (d.image_rel) {
      imgEl.innerHTML = `<img src="/crops/${d.image_rel}" alt="" onerror="this.parentElement.innerHTML='${ICON_IMAGE.replace(/'/g, '&apos;')}'"><div class="modal-img-meta">${d.image_rel.split('/').pop()}</div>`;
    } else {
      imgEl.innerHTML = `${ICON_IMAGE}<div class="modal-img-meta">no crop</div>`;
    }

    const fields = [
      ["Width",         `${d.width_cm} cm`],
      ["Height",        `${d.height_cm} cm`],
      ["Box Area",      `${d.box_area_cm2} cm²`],
      ["Mask Area",     `${d.pixel_area_cm2} cm²`],
      ["Box Area (m²)", `${d.box_area_m2} m²`],
      ["Repair Box",    d.repair_label],
      ["Repair Area",   `${d.repair_area_m2} m²`],
      ["Confidence",    `${(d.confidence*100).toFixed(0)}%`],
      ["Method",        d.method],
      ["Frames",        `${d.frames}`],
      ["GPS",           d.lat ? `${d.lat}, ${d.lon}` : "—"],
      ["Weather",       d.weather || "—"],
      ["Device",        d.device_id],
      ["Source",        d.source],
    ];
    $("#modal-grid").innerHTML = fields.map(([l, v]) => `
      <div class="modal-item">
        <div class="modal-item-label">${l}</div>
        <div class="modal-item-value">${v}</div>
      </div>
    `).join("");
    $("#overlay").classList.add("open");
  }

  // ── Sessions dropdown ─────────────────────────────────────────────────
  async function loadSessions() {
    const sessions = await fetchSessions();
    const sel = $("#session-select");
    if (!sessions.length) {
      sel.innerHTML = '<option value="">No CSVs found</option>';
      return;
    }
    sel.innerHTML = sessions.map(s =>
      `<option value="${s.name}">${s.label} · ${s.name}</option>`).join("");
    if (!currentSession) currentSession = sessions[0].name;
    sel.value = currentSession;
  }

  // ── Upload ────────────────────────────────────────────────────────────
  async function uploadBundle() {
    const csvFile = document.getElementById("csv-input").files[0];
    const zipFile = document.getElementById("zip-input").files[0];
    if (!csvFile) {
      toast("Please select a CSV file", true);
      return;
    }
    const fd = new FormData();
    fd.append("csv", csvFile);
    if (zipFile) fd.append("zip", zipFile);

    try {
      const r = await fetch("/api/upload_bundle", { method: "POST", body: fd });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
      toast(`Uploaded CSV: ${j.csv_filename}${zipFile ? " + crops" : ""}`);
      await loadSessions();
      currentSession = j.csv_filename;
      $("#session-select").value = j.csv_filename;
      const data = await fetchData(j.csv_filename);
      loadAndRender(data, j.csv_filename);
    } catch (e) {
      toast(`Upload failed: ${e.message}`, true);
    }
    // clear inputs
    document.getElementById("csv-input").value = "";
    document.getElementById("zip-input").value = "";
  }

  // Attach to button
  document.getElementById("upload-bundle-btn").addEventListener("click", uploadBundle);

  // ── Export ────────────────────────────────────────────────────────────
  function exportCSV() {
    const headers = ["id","timestamp","frames","width_cm","height_cm",
                     "box_area_cm2","pixel_area_cm2","box_area_m2",
                     "repair_w_m","repair_h_m","repair_area_m2","repair_label",
                     "confidence","method","lat","lon","weather",
                     "device_id","source"];
    const lines = [headers.join(",")];
    allData.forEach(d => {
      lines.push(headers.map(h => {
        const v = d[h] ?? "";
        return typeof v === "string" && v.includes(",") ? `"${v}"` : v;
      }).join(","));
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `pothole_summary_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    toast("CSV exported");
  }

  // ── Render ────────────────────────────────────────────────────────────
  function loadAndRender(data) {
    allData = data;
    updateStats(data);
    updateChart(data);
    updateMap(data);
    applyFilters();
  }


  // ── Init ──────────────────────────────────────────────────────────────
  document.addEventListener("DOMContentLoaded", async () => {
    initTheme();
    initMap();
    initChart();

    $("#search").addEventListener("input", applyFilters);
    $("#filter-size").addEventListener("change", applyFilters);
    $("#filter-conf").addEventListener("input", applyFilters);
    $("#filter-gps").addEventListener("change", applyFilters);
    $$("th[data-sort]").forEach(th =>
      th.addEventListener("click", () => sortBy(th.dataset.sort)));

    $("#file-input").addEventListener("change", handleUpload);
    $("#export-btn").addEventListener("click", exportCSV);

    $("#theme-toggle").addEventListener("click", () => {
      const cur = document.documentElement.dataset.theme === "light" ? "dark" : "light";
      setTheme(cur);
    });

    $("#session-select").addEventListener("change", async (e) => {
      currentSession = e.target.value;
      const data = await fetchData(currentSession);
      loadAndRender(data);
    });

    $("#modal-close").addEventListener("click", () =>
      $("#overlay").classList.remove("open"));
    $("#overlay").addEventListener("click", (e) => {
      if (e.target.id === "overlay") $("#overlay").classList.remove("open");
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") $("#overlay").classList.remove("open");
    });

    await loadSessions();
    const data = await fetchData();
    loadAndRender(data);

    $$(".tab-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const tabId = btn.dataset.tab;
        $$(".tab-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        $$(".tab-content").forEach(sec => sec.classList.remove("active"));
        document.getElementById(`${tabId}-section`).classList.add("active");
      });
    });

    // Group filters
    const groupFilters = ["group-search", "group-min-area", "group-max-area", "group-min-width", "group-max-width", "group-min-height", "group-max-height", "group-min-count"];
    groupFilters.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.addEventListener("input", () => applyGroupFilters());
    });

    // Group table sorting
    $$("#group-table th[data-sort-group]").forEach(th => {
      th.addEventListener("click", () => {
        const key = th.dataset.sortGroup;
        if (groupSortKey === key) groupSortAsc = !groupSortAsc;
        else { groupSortKey = key; groupSortAsc = true; }
        applyGroupFilters();
      });
    });

      });

})();
